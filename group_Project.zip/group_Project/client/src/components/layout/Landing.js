import { Redirect } from 'react-router-dom'

const Landing = () => {
	return <Redirect to='/login' />
}

export default Landing
